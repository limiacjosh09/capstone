<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Answer; // Ensure this model exists

class AnswerController extends Controller
{
    public function incrementClick($id)
    {
        $answer = Answer::find($id);

        if (!$answer) {
            return response()->json(['message' => 'Answer not found'], 404);
        }

        $answer->clicks += 1;
        $answer->save();

        return response()->json(['message' => 'Click updated', 'clicks' => $answer->clicks]);
    }
}
